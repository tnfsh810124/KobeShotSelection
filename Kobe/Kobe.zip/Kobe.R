library(MASS)

Kobe <- read.csv("Kobe.csv", header = T, sep = ",")
Kobe$matchup <- as.character(Kobe$matchup)
Kobe$matchup <- sapply(1:length(Kobe$matchup), 
       function(x) strsplit(Kobe$matchup[x], " ")[[1]][2])
attach(Kobe)

df <- na.omit(Kobe)
attach(df)
summary(Kobe)
table(combined_shot_type , shot_made_flag)
table(matchup , shot_made_flag)
chisq.test(table(matchup , shot_made_flag))


# Logistic under 
fit1 <- glm(shot_made_flag ~ combined_shot_type + factor(playoffs) + 
      minutes_remaining + period, family = "binomial")
summary(fit1)
prdct1 <- cut(predict(fit1, df, "response"), c(0,0.5,1), c(0, 1))
prdct.tb1 <- table(shot_made_flag , prdct1)
(prdct.tb1[1, 2] + prdct.tb1[2, 1])/sum(prdct.tb1)


fit2 <- lda(shot_made_flag ~ combined_shot_type + factor(playoffs) + 
      minutes_remaining + period, subset = is.na(Kobe$shot_made_flag)==FALSE)
prdct2 <- predict(fit2, df)$class
prdct.tb2 <- table(df$shot_made_flag , prdct2)
(prdct.tb2[1, 2] + prdct.tb2[2, 1])/sum(prdct.tb2)


fit3 <- qda(shot_made_flag ~ combined_shot_type + factor(playoffs) + 
              minutes_remaining + period, subset = is.na(Kobe$shot_made_flag)==FALSE)
prdct3 <- predict(fit3, df)$class
prdct.tb3 <- table(df$shot_made_flag , prdct3)
(prdct.tb3[1, 2] + prdct.tb3[2, 1])/sum(prdct.tb3)


